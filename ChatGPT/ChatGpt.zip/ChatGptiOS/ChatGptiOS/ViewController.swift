//
//  ViewController.swift
//  ChatGptiOS
//
//  Created by Nitin Bhatia on 22/04/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var btnSearchAgain: UIButton!
    @IBOutlet weak var btnReset: UIButton!
    @IBOutlet weak var btnStop: UIButton!
    @IBOutlet weak var txtViewResponse: UITextView!
    @IBOutlet weak var lblPlaceHolder: UILabel!
    @IBOutlet weak var btnSend: UIButton!
    @IBOutlet weak var txtViewQuestion: UITextView!
    
    //varaibles
    var writingTask: DispatchWorkItem?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        txtViewQuestion.heightAnchor.constraint (equalToConstant: 52.0).isActive = true
        setTextViewHeight(txtViewQuestion)
        txtViewQuestion.layer.cornerRadius = 4
        txtViewQuestion.delegate = self
        
    }
    
  
    
    @IBAction func btnSendAction(_ sender: Any) {
        //role : system, user, or assistant
        //https://platform.openai.com/docs/api-reference/chat/create
        let params = Params(model: "gpt-3.5-turbo", messages: [.init(role: "user", content: "\(txtViewQuestion.text!)")], temperature: 0.7)
        
        Task {
            let data = await NetworkService.getData(params: params)
            //self.txtViewResponse.text = data?.choices?.first?.message?.content ?? ""
            self.writingTask = self.txtViewResponse.setTextWithTypeAnimation(typedText: data?.choices?.first?.message?.content ?? "")
            self.btnStop.isEnabled = true
            self.btnReset.isEnabled = true
            self.btnSend.isEnabled = false
            self.btnSearchAgain.isEnabled = true
        }
        
    }
    
    @IBAction func btnSearchAgainAction(_ sender: Any) {
        btnSendAction(btnSend)
    }
    
    @IBAction func btnResetAction(_ sender: Any) {
        txtViewQuestion.text = ""
        txtViewResponse.text = ""
        self.btnStop.isEnabled = false
        self.btnReset.isEnabled = false
        self.btnSend.isEnabled = false
        self.btnSearchAgain.isEnabled = false
    }
    
    @IBAction func btnStopAction(_ sender: Any) {
        writingTask?.cancel()
    }
    
    
}

//MARK: - UITextViewDelegate
extension ViewController: UITextViewDelegate {
    func textViewDidChange(_ textView: UITextView) {
        
       if textView.text.isEmpty {
            lblPlaceHolder.isHidden = false
           btnSend.isEnabled = false
        } else {
            lblPlaceHolder.isHidden = true
            btnSend.isEnabled = true
        }
        
        setTextViewHeight(textView)
    }
    
    func setTextViewHeight(_ textView: UITextView) {
        let size = CGSize(width: textView.frame.size.width, height: .infinity)
        let estimatedSize = textView.sizeThatFits(size)
        guard textView.contentSize.height < 100.0 else { textView.isScrollEnabled = true; return }
        textView.isScrollEnabled = false
        textView.constraints.forEach { (constraint) in
            if constraint.firstAttribute == .height {
                constraint.constant = estimatedSize.height
            }
        }
    }
}


extension UITextView {
    func setTextWithTypeAnimation(typedText: String, characterDelay: TimeInterval = 5.0) -> DispatchWorkItem? {
        text = ""
        var writingTask: DispatchWorkItem?
        writingTask = DispatchWorkItem { [weak weakSelf = self] in
            for character in typedText {
                DispatchQueue.main.async {
                    if character == "\n" {
                        print("new line")
                    }
                    weakSelf?.text!.append(character)
                }
                Thread.sleep(forTimeInterval: characterDelay/100)
                
                if writingTask?.isCancelled ?? false {
                    break
                }
            }
        }
        
        if let task = writingTask {
            let queue = DispatchQueue(label: "typespeed", qos: DispatchQoS.userInteractive)
            queue.asyncAfter(deadline: .now() + 0.05, execute: task)
        }
        
        return writingTask
    }
    
}

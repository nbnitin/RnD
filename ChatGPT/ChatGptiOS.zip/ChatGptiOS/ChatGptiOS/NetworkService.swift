//
//  NetworkService.swift
//  ChatGptiOS
//
//  Created by Nitin Bhatia on 22/04/23.
//

import Foundation
import Alamofire

struct Params: Encodable {
    
    struct ParamsMessage : Encodable {
        let role : String?
        let content : String?
    }
    
    let model : String
    let messages : [ParamsMessage]?
    let temperature : CGFloat?
}

struct AIResponse : Decodable {
    
    //    {"id":"chatcmpl-78ShcbWYXuhmsudfazXWK6gVrkHO6","object":"chat.completion","created":1682251312,"model":"gpt-3.5-turbo-0301","usage":{"prompt_tokens":13,"completion_tokens":14,"total_tokens":27},"choices":[{"message":{"role":"assistant","content":"Why did the tomato turn red?\n\nBecause it saw the salad dressing!"},"finish_reason":"stop","index":0}]}
    //
    let id : String?
    let object : String?
    let created : Double?
    let model : String?
    let usage : Usage?
    let choices : [Choices]?
    let finish_reason : String?
    let index : Int?
    
    struct Usage : Decodable {
        let prompt_token: Int?
        let completion_token : Int?
        let total_token : Int?
    }
    
    struct Choices : Decodable {
        let message : Messages?
        
        struct Messages : Decodable {
            let role : String?
            let content : String?
        }
    }
    
    
    
}


let API_KEY = "ENTER YOUR API KEY"

class NetworkService {
    
    class func getData(params: Params) async -> AIResponse? {
        return await withCheckedContinuation({ continuation in
            let url = URL(string: "https://api.openai.com/v1/chat/completions")
            
            let headers =  HTTPHeader(name: "Authorization", value: "Bearer " + API_KEY)
            let hee = HTTPHeader(name: "Content-Type", value: "application/json")
            
            let params = params
            
            
            AF.request(url!,method: .post, parameters: params, encoder: .json  ,headers: HTTPHeaders([headers, hee])).responseJSON{response in
                
                if let data = response.data {
                    let data = try! JSONDecoder().decode(AIResponse.self, from: data)
                    continuation.resume(returning : data)
                }
            }
        })
    }
    
}
